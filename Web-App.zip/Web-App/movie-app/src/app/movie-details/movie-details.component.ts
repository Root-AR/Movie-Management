import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {MovieDetailsService} from './movie-details.service';
import { FormGroup, FormControl } from '@angular/forms';
import {Router} from "@angular/router";

@Component({
  selector: 'app-movie-details',
  templateUrl: './movie-details.component.html',
  styleUrls: ['./movie-details.component.css']
})
export class MovieDetailsComponent implements OnInit, OnDestroy {

  public id: string;
  public movie: any;
  public isContentReady: boolean;
  public movieEditMode : boolean;
  public addRatingMode: boolean;
  public movieForm: FormGroup;
  public addRatingForm: FormGroup;
  public fileToUpload: File;
  public isFileChosen: boolean;
  private sub: any;
  private copyMovie: any;


  constructor(private route: ActivatedRoute, private movieDetailsService: MovieDetailsService,private router: Router) {
    this.sub = this.route.params.subscribe(params => {
      this.id = params.id;
      this.movieDetailsService.getMovieById(this.id).subscribe((movie: any) => {
            this.movie = movie;
            this.isContentReady = true;
            this.initializeMovieMetadataForm(this.movie);
            this.initializeAddRatingForm();
          },
          error => this.router.navigate(['/movies']));
      });
  }

  initializeMovieMetadataForm = (movie: any) => {
    let formControlObject = {};
    Object.keys(movie).forEach( (value, index) => {
      formControlObject[value] = new  FormControl(movie[value]);
    });
    this.movieForm = new FormGroup(formControlObject);
  }

  initializeAddRatingForm = () => {
    this.addRatingForm = new FormGroup({
      createdBy : new FormControl(),
      review: new FormControl(),
      rating: new FormControl()
    });
  }
  updateMovieMetadata = (movieForm: FormGroup) => {
    this.movieDetailsService.updateMovieById(this.id, movieForm.value)
    .subscribe(
      (data: any) => { this.movieEditMode = false; this.movie = movieForm.value; },
      error => console.log(error)
    );
  }

  addMovieRating = (addRatingForm: FormGroup) => {
    this.movieDetailsService.addMovieRatings(this.id, addRatingForm.value)
    .subscribe(
      (data: any) => { this.addRatingMode = false; this.movie.ratings.push(addRatingForm.value);},
      error => console.log(error)
    );
  }
  handleFileInput = (files: FileList) => {
    this.fileToUpload = files.item(0);
    this.isFileChosen = true;
  }

  uploadFile = () => {
    this.movieDetailsService.uploadFiles(this.id,this.fileToUpload)
    .subscribe(
      (data: any) => { this.movie.fileUrl = data.location;  console.log(this.movie); this.isFileChosen = false;},
      error => console.log(error)
    );
  }

  ngOnInit() {}

  ngOnDestroy() {
    this.sub.unsubscribe();
  }


}
