import { Injectable } from '@angular/core';
import { NetworkService } from '../utils/network.service';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MovieDetailsService {

  constructor(private networkService: NetworkService) { }

  getMovieById = (id: string) => {
    return this.networkService.get(environment.apiBaseUrl + environment.moviesEndpoint + '/' + id);
  }

  updateMovieById = (id: string, movie: any) => {
    return this.networkService.put(environment.apiBaseUrl + environment.moviesEndpoint + '/' + id, movie);
  }

  addMovieRatings = (id: string, rating: any) => {
    return this.networkService.post(environment.apiBaseUrl + environment.moviesEndpoint + '/' + id + '/' + environment.ratingsEndpoint, rating);
  }

  uploadFiles = (id: string,file: File) => {
    return this.networkService.postFile(environment.apiBaseUrl + environment.moviesEndpoint + '/' + id + '/' + environment.uploadEndpoint,file);
  };

}
