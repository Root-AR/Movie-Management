import { Injectable } from '@angular/core';
import { NetworkService } from '../utils/network.service';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MoviesService {

  constructor(private networkService: NetworkService) { }

  getMovies = () => {
    return this.networkService.get(environment.apiBaseUrl + environment.moviesEndpoint);
  }
  deleteMovies = (movieid: string) => {
    return this.networkService.delete(environment.apiBaseUrl + environment.moviesEndpoint + '/' + movieid);
  }

  addMovie = (movie: any) => {
    return this.networkService.post(environment.apiBaseUrl + environment.moviesEndpoint, movie);
  }
}
