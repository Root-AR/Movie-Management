import { Component, OnInit } from '@angular/core';
import { MoviesService } from './movies.service';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {

  moviesList: any[] = [];
  movieForm: FormGroup;
  addMovieMode: boolean;

  constructor(private moviesService: MoviesService) {
    this.movieForm = this.createFormGroup();
    this.getAllMovies();
  }

  ngOnInit() {
  }

  createFormGroup() {
    return new FormGroup({
        name: new FormControl(),
        createdBy: new FormControl(),
    });
  }

  deleteMovie(movieId: string, index: number) {
    this.moviesService.deleteMovies(movieId).subscribe(() => {
      this.moviesList.splice(index, 1);
    });
  }

  getAllMovies() {
    this.moviesService.getMovies().subscribe((movies: any) => {
      this.moviesList = movies;
    });
  }
  addMovie(movieForm: FormGroup) {
    this.moviesService.addMovie(movieForm.value).subscribe((data) => {
        this.addMovieMode = false;
        this.getAllMovies();
    });
  }

}
