package com.netapp.movie.exception;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class MovieMissingParameterException extends RuntimeException {
	 public MovieMissingParameterException(String exception) {
		    super(exception);
		  }
}
