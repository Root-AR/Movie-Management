package com.netapp.movie.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Repository;

import com.netapp.movie.entities.Movie;
import com.netapp.movie.entities.Rating;
import com.netapp.movie.exception.MovieMissingParameterException;

@Repository
public class MovieDAO {
	
	List<Movie> movies = new ArrayList<Movie>();
	
	public List<Movie> getAllMovies(){
		return movies;
	}

	
	public String addMovie(Movie movie) {
		String movieId = UUID.randomUUID().toString();
		movie.setId(movieId); 
		movie.setCreatedAt(new Date());
		
		if(!movie.getRatings().isEmpty()) {
			for(Rating rating: movie.getRatings()) {
				if(rating.getRating() > 5 || rating.getRating() <1 ) {
					throw new MovieMissingParameterException("Please provide rating within 1-5 range");
				}
					
				rating.setId(UUID.randomUUID().toString());
				rating.setMovieId(movieId);
				rating.setCreatedAt(new Date());
			}
		}
		movies.add(movie);
		return movie.getId();
	}
	
	public Movie getMovieById(String id){
		for (Movie movie : movies) {
	        if (movie.getId().equals(id)) {
	            return movie;
	        }
	    }
		return null;
	}
	
	public String updateMovieById(Movie updatedMovie) {
		for (Movie movie : movies) {
	        if (movie.getId().equals(updatedMovie.getId())) {
	            movie.setName(updatedMovie.getName());
	            movie.setCreatedAt(updatedMovie.getCreatedAt());
	            movie.setCreatedBy(updatedMovie.getCreatedBy());
	            movie.setRatings(updatedMovie.getRatings());
	            return movie.getId();
	        }
	    }
		return null;
	}
	
	public void deleteMovie(String id) {
		movies.removeIf(movie -> movie.getId().equals(id));
	}
	
	
	public List<Rating> getAllMovieRatings(String movieId){
		Movie movie = this.getMovieById(movieId);
		return movie.getRatings();
	}
	
	public String addMovieRating(Rating rating, String movieId) {
		Movie movie = this.getMovieById(movieId);
		if(rating.getRating() > 5 || rating.getRating() <1 ) {
			throw new MovieMissingParameterException("Please provide rating within 1-5 range");
		}
		rating.setId(UUID.randomUUID().toString());
		rating.setMovieId(movieId);
		rating.setCreatedAt(new Date());
		rating.setMovieId(movieId);
		movie.getRatings().add(rating);
		return rating.getId();

	}

	public void deleteMovieRating(String ratingId, String movieId) {
		Movie movie = this.getMovieById(movieId);
		for (Rating rating : movie.getRatings()) {
			if (rating.getId().equals(ratingId)) {
				movie.getRatings().remove(rating);
			}
		}
	}

}
