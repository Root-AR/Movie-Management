package com.netapp.movie.dao;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.io.Resources;

@Repository
public class FileDAO {
	
	private static String UPLOADED_FOLDER = "/FilesStorage";
	
	@Autowired
	ResourceLoader resourceLoader;
	
	private String getFilesStorageLocation() {
		String pathString = System.getProperty("user.dir")+ UPLOADED_FOLDER;
		Path  path = Paths.get(pathString) ;
		
		if (Files.exists(path)) {
		    return pathString;
		}
		File file = new File(pathString);
		file.mkdirs();
		return pathString;
	}
	
	public URI storeFile(MultipartFile file) {
		byte[] bytes;
		String location = getFilesStorageLocation()+"/" +file.getOriginalFilename();
		
		try {
			bytes = file.getBytes();
			Path path = Paths.get(location); 
			Files.write(path, bytes);
			return path.toUri();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return null;
	}

}
