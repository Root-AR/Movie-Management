package com.netapp.movie.services;

import java.net.URI;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.netapp.movie.dao.FileDAO;
import com.netapp.movie.exception.MovieMissingParameterException;

@Service
public class FileService {
	
	@Autowired
	FileDAO fileDAO;
	
	public URI storeFile (MultipartFile file) {
		 if (file.isEmpty()) {
	         throw new  MovieMissingParameterException("Bad input file"); 
	      }
		 return fileDAO.storeFile(file);
		 
	}

}
