package com.netapp.movie.endpoints;

import java.net.URI;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.netapp.movie.entities.Movie;
import com.netapp.movie.entities.Rating;
import com.netapp.movie.services.MovieService;

import io.swagger.annotations.Api;

@Api(tags = "Movies")
@RestController
@RequestMapping("/api/v1")
public class MovieEndpoint {
	
	  @Autowired
	  MovieService movieService;
	  
	  @GetMapping("/movies")
	  public ResponseEntity<List<Movie>> getAllMovies() {
		return ResponseEntity.ok().body(movieService.getAllMovies());
	  }
	  
	  @GetMapping("/movies/{movieId}")
	  public ResponseEntity<Movie> getMovieById(@PathVariable String movieId) {
		return ResponseEntity.ok().body(movieService.getMovieById(movieId));
	  }
	  
	  @PostMapping("/movies")
	  public ResponseEntity<Object> addMovie(@RequestBody Movie movie){
		  String id = movieService.addMovie(movie);
		  URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
					.buildAndExpand(id).toUri();
		  return ResponseEntity.created(location).build();
	  }
	  
	  @PutMapping("/movies/{movieId}")
	  public ResponseEntity<String> updateMovie(@RequestBody Movie movie,@PathVariable String movieId){
		  movieService.updateMovieById(movie,movieId);
		  return ResponseEntity.ok().build();
	  }
	  
	  @DeleteMapping("/movies/{movieId}")
	  public ResponseEntity<Object> deleteMovie(@PathVariable String movieId) {
		  movieService.deleteMovie(movieId);
		  return ResponseEntity.noContent().build();
	  }
	  
	  @GetMapping("/movies/{movieId}/ratings")
	  public ResponseEntity<List<Rating>> getAllMovieRatings(@PathVariable String movieId) {
		return ResponseEntity.ok().body(movieService.getAllMovieRatings(movieId));
	  }
	  
	  @PostMapping("/movies/{movieId}/ratings")
	  public ResponseEntity<Object> addMovieRating(@RequestBody Rating rating,@PathVariable String movieId){
		  String id = movieService.addMovieRating(rating,movieId);
		  URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
					.buildAndExpand(id).toUri();
		  return ResponseEntity.created(location).build();
	  }
	  
	  @DeleteMapping("/movies/{movieId}/ratings/{ratingId}")
	  public ResponseEntity<Object> deleteMovieRating(@PathVariable String movieId,@PathVariable String ratingId){
		   movieService.deleteMovieRating(ratingId, movieId);
		   return ResponseEntity.noContent().build();
	  }
	  
	  @PostMapping("/movies/{movieId}/upload")
	  public ResponseEntity<Object> addMovieFile(@RequestParam("file") MultipartFile file,@PathVariable String movieId){
		  Map fileDetails = movieService.attachMovieFile(file, movieId);
		  return ResponseEntity.ok().body(fileDetails);
	  }
	 

}
