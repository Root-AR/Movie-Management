package com.netapp.movie.services;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.netapp.movie.dao.MovieDAO;
import com.netapp.movie.entities.Movie;
import com.netapp.movie.entities.Rating;
import com.netapp.movie.exception.MovieMissingParameterException;
import com.netapp.movie.exception.MovieNotFoundException;

/*
 * The service layer is used to interact with perform business logic and
 * interact with Repository layer 
 */

@Service
public class MovieService {
	
	@Autowired
	MovieDAO movieDAO;
	
	@Autowired
	FileService fileService;
	
	private final String LOCATION_CONSTANT = "location";
	
	public List<Movie> getAllMovies() {
		return movieDAO.getAllMovies();
	}
	
	public Movie getMovieById(String id) {
		if(id==null || id.equals(" ")|| id.equals("")) {
			throw new MovieMissingParameterException("Please provide valid ID");
		}
		Movie movie = movieDAO.getMovieById(id);
		if(movie==null) {
			throw new MovieNotFoundException("Movie not Found");
		}
		return movie;
	}
	
	public String updateMovieById(Movie movie, String id){
		if(id==null || id.equals(" ")|| id.equals("") || !movie.getId().equals(id)) {
			throw new MovieMissingParameterException("Please provide valid ID");
		}
		String updatedMovieId = movieDAO.updateMovieById(movie);
		if(updatedMovieId == null) {
			throw new MovieNotFoundException("Movie not Found");
		}
		return updatedMovieId;
	}
	
	public void deleteMovie(String id) {
		if(id==null || id.equals(" ")|| id.equals("")) {
			throw new MovieMissingParameterException("Please provide valid ID");
		}
		movieDAO.deleteMovie(id);
	}
	
	public String addMovie(Movie movie) {
		return movieDAO.addMovie(movie);
	}
	
	public List<Rating> getAllMovieRatings(String movieId){
		this.isMovieExists(movieId);
		return movieDAO.getAllMovieRatings(movieId);
	}
	
	
	public String addMovieRating(Rating rating, String movieId) {
		this.isMovieExists(movieId);
		return movieDAO.addMovieRating(rating, movieId);
	}
	
	public void deleteMovieRating(String ratingId, String movieId) {
		this.isMovieExists(movieId);
		movieDAO.deleteMovieRating(ratingId, movieId);
	}
	
	private Boolean isMovieExists(String movieId) {
		this.getMovieById(movieId);
		return true;
	}
	
	public Map attachMovieFile(MultipartFile file,String movieId) {
		Movie movie = this.getMovieById(movieId);
		URI fileUrl  = fileService.storeFile(file);
		movie.setFileUrl(fileUrl.getPath());
		this.updateMovieById(movie, movieId);
		
		Map<String,String> fileDetails = new HashMap<String,String>();
		fileDetails.put(LOCATION_CONSTANT, fileUrl.toString());
		
		return fileDetails;
	}

}
